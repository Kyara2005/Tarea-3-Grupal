public class Jugador {
    // Atributos
    private String nombreJugador;
    private int numeroJugador;
    private String posicion;

    // Constructor
    public Jugador(String nombreJugador, int numeroJugador, String posicion) {
        this.nombreJugador = nombreJugador;
        this.numeroJugador = numeroJugador;
        this.posicion = posicion;
    }

    // Método para mostrar la información del jugador
    public void mostrarInformacionJugador() {
        System.out.println("Nombre del Jugador: " + nombreJugador);
        System.out.println("Número del Jugador: " + numeroJugador);
        System.out.println("Posición: " + posicion);
    }

    // Método para actualizar la posición
    public void actualizarPosicion(String nuevaPosicion) {
        this.posicion = nuevaPosicion;
        System.out.println("Posición actualizada a: " + nuevaPosicion);
    }
}
