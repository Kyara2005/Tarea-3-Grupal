public class Main {
    public static void main(String[] args) {
        // Crear el objeto jugador
        Jugador jugador = new Jugador("Neymar Jr", 10, "Delantero");

        // Mostrar la información
        jugador.mostrarInformacionJugador();

        // Actualizar la posición
        jugador.actualizarPosicion("Centrocampista");

        // Mostrar nuevamente la información actualizada
        jugador.mostrarInformacionJugador();
    }
}
